package assignment3;

public class Color {
	private String ident;
	/**
	 * Initializes the private String object to the input String
	 */
	public Color(String in)
	{
		ident = in;
	}
	/**
	 * Basic getter method
	 */
	public String getIdent()
	{
		return ident;
	}
}
